package business.model;

public class BusinessVO {
	private int b_rating;
	private String b_id,b_name,b_pass,b_tel,b_email,b_regdate,b_lastdate,b_number;
	public String getB_number() {
		return b_number;
	}
	public void setB_number(String b_number) {
		this.b_number = b_number;
	}
	public int getB_rating() {
		return b_rating;
	}
	public void setB_rating(int b_rating) {
		this.b_rating = b_rating;
	}
	public String getB_id() {
		return b_id;
	}
	public void setB_id(String b_id) {
		this.b_id = b_id;
	}
	public String getB_name() {
		return b_name;
	}
	public void setB_name(String b_name) {
		this.b_name = b_name;
	}
	public String getB_pass() {
		return b_pass;
	}
	public void setB_pass(String b_pass) {
		this.b_pass = b_pass;
	}
	public String getB_tel() {
		return b_tel;
	}
	public void setB_tel(String b_tel) {
		this.b_tel = b_tel;
	}
	public String getB_email() {
		return b_email;
	}
	public void setB_email(String b_email) {
		this.b_email = b_email;
	}
	public String getB_regdate() {
		return b_regdate;
	}
	public void setB_regdate(String b_regdate) {
		this.b_regdate = b_regdate;
	}
	public String getB_lastdate() {
		return b_lastdate;
	}
	public void setB_lastdate(String b_lastdate) {
		this.b_lastdate = b_lastdate;
	}
	
}
