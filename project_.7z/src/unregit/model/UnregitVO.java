package unregit.model;

public class UnregitVO {
	private String ur_email,ur_name,ur_tel,reserv_num,ur_pass,regdate;

	public String getUr_email() {
		return ur_email;
	}

	public void setUr_email(String ur_email) {
		this.ur_email = ur_email;
	}

	public String getUr_name() {
		return ur_name;
	}

	public void setUr_name(String ur_name) {
		this.ur_name = ur_name;
	}

	public String getUr_tel() {
		return ur_tel;
	}

	public void setUr_tel(String ur_tel) {
		this.ur_tel = ur_tel;
	}

	public String getReserv_num() {
		return reserv_num;
	}

	public void setReserv_num(String reserv_num) {
		this.reserv_num = reserv_num;
	}

	public String getUr_pass() {
		return ur_pass;
	}

	public void setUr_pass(String ur_pass) {
		this.ur_pass = ur_pass;
	}

	public String getRegdate() {
		return regdate;
	}

	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	
}
