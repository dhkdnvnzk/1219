package unregit.model;

public class UnregitDAO {

}
